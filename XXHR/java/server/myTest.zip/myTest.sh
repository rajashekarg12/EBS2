#!/bin/bash

echo "=== Starting test_oaf_script.sh execution ==="

# Log execution details
echo "User: $(whoami)"
echo "Date: $(date)"

# Create a test file
TEST_FILE="/tmp/flexdeploy_oaf_script_test_$(date +%s).txt"
echo "This file was created by test_oaf_script.sh on $(date)" > "$TEST_FILE"

# Confirm the file was created
if [ -f "$TEST_FILE" ]; then
  echo "Test file created successfully: $TEST_FILE"
else
  echo "Failed to create test file!"
  exit 1
fi

echo "=== Script executed successfully ==="
exit 0
